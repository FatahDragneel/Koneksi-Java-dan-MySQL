/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan1;

/**
 *
 * @author Fatah
 */
import java.sql.*;
public class Koneksi{
    static final String driver= "com.mysql.jdbc.Driver";
    static final String url= "jdbc:mysql://localhost/penjualan_barang";
    static final String user= "root";
    static final String upass= "";
    static Connection conn;
    static Statement stat; 
        public static void konek() {
            try{
                Class.forName(driver);
                conn=DriverManager.getConnection(url, user, upass);
                System.out.println("Koneksi Berhasil");
               }catch(Exception e){
                System.out.println(e);
                }
            }
    }



     

